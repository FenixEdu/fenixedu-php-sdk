<?php
	$_FENIX_EDU["access_key"] = "";
	$_FENIX_EDU["secret_key"] = "";
	$_FENIX_EDU["callback_url"] = "";
	$_FENIX_EDU["api_base_url"] = "https://fenix.ist.utl.pt";
?>
